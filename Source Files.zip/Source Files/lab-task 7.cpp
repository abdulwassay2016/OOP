#include<iostream>
#include<math.h>
using namespace std;
int main()
{
int o,p,q,root;
double qe=0.00;
cout<<"enter the value of a"<<endl;
cin>>o;
cout<<"enter the value of b"<<endl;
cin>>p;
cout<<"enter the value of c"<<endl;
cin>>q;
root=sqrt((p*p)-(4*o*q));
qe=-p+root/(2*q);
cout<<"quardatic equation is="<<qe;
return 0;
}
