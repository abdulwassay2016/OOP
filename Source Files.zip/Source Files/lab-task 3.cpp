#include<iostream>
using namespace std;
int main(){
	float l,w,h,volume;
	cout<<"Enter length of box: ";
	cin>>l;
	cout<<"Enter width of box: ";
	cin>>w;
	cout<<"Enter heigth of box: ";
	cin>>h;
	volume=l*w*h;
	cout<<"Volume of box= "<<volume;
			
	
}
