#include<iostream>
using namespace std;
int main()
{
	int celc,farh;
	cout<<"Enter temprature in Celcius : ";
	cin>>celc;
	farh=celc*9/5+32;
	cout<<"Temprature in Farenhite = "<<farh;
	return 0;
}
