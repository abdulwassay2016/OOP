#include<iostream>
using namespace std;
int main()
{
	char o;
	cout<<"Enter a character in uppercase : ";
	cin>>o;
	o=o+32;
	cout<<"character in lowercase = "<<o;
}
