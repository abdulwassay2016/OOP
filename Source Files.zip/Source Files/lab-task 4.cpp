#include<iostream>
using namespace std;
int main()
{
	int o,p,q;
	cout<<"Enter the value of 1st variable : ";
	cin>>o;
	cout<<"Enter the value of 2nd variable : ";
	cin>>p;
	cout<<"Enter the value of 3rd variable : ";
	cin>>q;
	if(o>p){
		if(o>q){
			cout<<"1st varibale is greatest: "<<o;
		}
		
	}
	else if(p>o)
	{
		if(p>q){
			cout<<"2nd varibale is greatest: "<<p;
		
		}
	}
	else
	cout<<"3rd varibale is greatest: "<<q;
	return 0;
}
