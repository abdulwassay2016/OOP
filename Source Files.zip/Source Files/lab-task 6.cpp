#include <iostream>
using namespace std;
int main()
{
 char o;
 cout << "Enter a character: ";
 cin >> o;
 cout << "ASCII Value of " << o << " is " << int(o);
 return 0;
}
