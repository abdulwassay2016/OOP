#include<iostream>
using namespace std;
int main()
{
float dld,hrm,itc,eng,cal,pf,total,perc;
cout<<"Enter the Marks obtained in dld: ";
cin>>dld;
cout<<"Enter the Marks obtained in hrm: ";
cin>>hrm;
cout<<"Enter the Marks obtained in itc: ";
cin>>itc;
cout<<"Enter the Marks obtained in eng: ";
cin>>eng;
cout<<"Enter the Marks obtained in cal: ";
cin>>cal;
cout<<"Enter the Marks obtained in pf: ";
cin>>pf;
total=dld+hrm+itc+eng+cal+pf;
perc=(total/500)*100;
cout<<"The Percentage marks are:"<<perc;
return 0;
}

